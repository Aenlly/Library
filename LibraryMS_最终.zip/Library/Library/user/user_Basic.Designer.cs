﻿namespace Library.user
{
    partial class user_Basic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.text_id = new System.Windows.Forms.TextBox();
            this.text_name = new System.Windows.Forms.TextBox();
            this.text_tel = new System.Windows.Forms.TextBox();
            this.text_number = new System.Windows.Forms.TextBox();
            this.text_book = new System.Windows.Forms.TextBox();
            this.btn_edit = new System.Windows.Forms.Button();
            this.text_position = new System.Windows.Forms.TextBox();
            this.btn_no = new System.Windows.Forms.Button();
            this.rbtn_male = new System.Windows.Forms.RadioButton();
            this.rbtn_female = new System.Windows.Forms.RadioButton();
            this.cmb_college = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "学号：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 14);
            this.label2.TabIndex = 1;
            this.label2.Text = "姓名：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 14);
            this.label3.TabIndex = 2;
            this.label3.Text = "性别：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 14);
            this.label4.TabIndex = 3;
            this.label4.Text = "学院：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 193);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 14);
            this.label6.TabIndex = 5;
            this.label6.Text = "用户组：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 224);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 14);
            this.label9.TabIndex = 8;
            this.label9.Text = "可借数量：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 261);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 14);
            this.label11.TabIndex = 10;
            this.label11.Text = "累计借书：";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(87, 298);
            this.panel1.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 156);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 14);
            this.label5.TabIndex = 4;
            this.label5.Text = "手机号：";
            // 
            // text_id
            // 
            this.text_id.Enabled = false;
            this.text_id.Location = new System.Drawing.Point(119, 14);
            this.text_id.Name = "text_id";
            this.text_id.Size = new System.Drawing.Size(151, 23);
            this.text_id.TabIndex = 0;
            this.text_id.TabStop = false;
            // 
            // text_name
            // 
            this.text_name.Enabled = false;
            this.text_name.Location = new System.Drawing.Point(119, 54);
            this.text_name.Name = "text_name";
            this.text_name.Size = new System.Drawing.Size(107, 23);
            this.text_name.TabIndex = 1;
            this.text_name.TabStop = false;
            // 
            // text_tel
            // 
            this.text_tel.Enabled = false;
            this.text_tel.Location = new System.Drawing.Point(119, 162);
            this.text_tel.MaxLength = 11;
            this.text_tel.Name = "text_tel";
            this.text_tel.Size = new System.Drawing.Size(151, 23);
            this.text_tel.TabIndex = 5;
            this.text_tel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_tel_KeyPress);
            // 
            // text_number
            // 
            this.text_number.Enabled = false;
            this.text_number.Location = new System.Drawing.Point(119, 234);
            this.text_number.Name = "text_number";
            this.text_number.Size = new System.Drawing.Size(51, 23);
            this.text_number.TabIndex = 7;
            this.text_number.TabStop = false;
            // 
            // text_book
            // 
            this.text_book.Enabled = false;
            this.text_book.Location = new System.Drawing.Point(119, 271);
            this.text_book.Name = "text_book";
            this.text_book.Size = new System.Drawing.Size(98, 23);
            this.text_book.TabIndex = 8;
            this.text_book.TabStop = false;
            // 
            // btn_edit
            // 
            this.btn_edit.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_edit.Location = new System.Drawing.Point(18, 338);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(102, 32);
            this.btn_edit.TabIndex = 9;
            this.btn_edit.Text = "修改信息";
            this.btn_edit.UseVisualStyleBackColor = true;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // text_position
            // 
            this.text_position.Enabled = false;
            this.text_position.Location = new System.Drawing.Point(119, 199);
            this.text_position.Name = "text_position";
            this.text_position.Size = new System.Drawing.Size(68, 23);
            this.text_position.TabIndex = 6;
            this.text_position.TabStop = false;
            // 
            // btn_no
            // 
            this.btn_no.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_no.Location = new System.Drawing.Point(143, 338);
            this.btn_no.Name = "btn_no";
            this.btn_no.Size = new System.Drawing.Size(102, 32);
            this.btn_no.TabIndex = 10;
            this.btn_no.Text = "返回";
            this.btn_no.UseVisualStyleBackColor = true;
            this.btn_no.Click += new System.EventHandler(this.btn_no_Click);
            // 
            // rbtn_male
            // 
            this.rbtn_male.AutoSize = true;
            this.rbtn_male.Enabled = false;
            this.rbtn_male.Location = new System.Drawing.Point(119, 94);
            this.rbtn_male.Name = "rbtn_male";
            this.rbtn_male.Size = new System.Drawing.Size(39, 18);
            this.rbtn_male.TabIndex = 2;
            this.rbtn_male.Text = "男";
            this.rbtn_male.UseVisualStyleBackColor = true;
            // 
            // rbtn_female
            // 
            this.rbtn_female.AutoSize = true;
            this.rbtn_female.Enabled = false;
            this.rbtn_female.Location = new System.Drawing.Point(178, 94);
            this.rbtn_female.Name = "rbtn_female";
            this.rbtn_female.Size = new System.Drawing.Size(39, 18);
            this.rbtn_female.TabIndex = 3;
            this.rbtn_female.Text = "女";
            this.rbtn_female.UseVisualStyleBackColor = true;
            // 
            // cmb_college
            // 
            this.cmb_college.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_college.Enabled = false;
            this.cmb_college.FormattingEnabled = true;
            this.cmb_college.Location = new System.Drawing.Point(117, 128);
            this.cmb_college.Name = "cmb_college";
            this.cmb_college.Size = new System.Drawing.Size(151, 22);
            this.cmb_college.TabIndex = 13;
            // 
            // user_Basic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(280, 396);
            this.Controls.Add(this.cmb_college);
            this.Controls.Add(this.rbtn_female);
            this.Controls.Add(this.rbtn_male);
            this.Controls.Add(this.btn_no);
            this.Controls.Add(this.btn_edit);
            this.Controls.Add(this.text_book);
            this.Controls.Add(this.text_number);
            this.Controls.Add(this.text_position);
            this.Controls.Add(this.text_tel);
            this.Controls.Add(this.text_name);
            this.Controls.Add(this.text_id);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "user_Basic";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "基本信息";
            this.Load += new System.EventHandler(this.user_Basic_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox text_id;
        private System.Windows.Forms.TextBox text_name;
        private System.Windows.Forms.TextBox text_tel;
        private System.Windows.Forms.TextBox text_number;
        private System.Windows.Forms.TextBox text_book;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox text_position;
        private System.Windows.Forms.Button btn_no;
        private System.Windows.Forms.RadioButton rbtn_male;
        private System.Windows.Forms.RadioButton rbtn_female;
        private System.Windows.Forms.ComboBox cmb_college;
    }
}