﻿namespace Library.admin
{
    partial class admin_FeedBack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.rtb_rcd = new System.Windows.Forms.RichTextBox();
            this.rtb_cnt = new System.Windows.Forms.RichTextBox();
            this.text_title = new System.Windows.Forms.TextBox();
            this.text_atm = new System.Windows.Forms.TextBox();
            this.text_stm = new System.Windows.Forms.TextBox();
            this.text_id = new System.Windows.Forms.TextBox();
            this.text_solve = new System.Windows.Forms.TextBox();
            this.btn_ok = new System.Windows.Forms.Button();
            this.btn_no = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "反馈用户ID：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 14);
            this.label2.TabIndex = 1;
            this.label2.Text = "反馈标题：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 14);
            this.label3.TabIndex = 2;
            this.label3.Text = "反馈内容：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 349);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 14);
            this.label4.TabIndex = 3;
            this.label4.Text = "反馈回复：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 14);
            this.label5.TabIndex = 4;
            this.label5.Text = "提交时间：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 111);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 14);
            this.label6.TabIndex = 5;
            this.label6.Text = "回复时间：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 499);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 14);
            this.label7.TabIndex = 6;
            this.label7.Text = "是否已回复：";
            // 
            // rtb_rcd
            // 
            this.rtb_rcd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtb_rcd.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.rtb_rcd.Location = new System.Drawing.Point(105, 349);
            this.rtb_rcd.MaxLength = 100;
            this.rtb_rcd.Name = "rtb_rcd";
            this.rtb_rcd.ReadOnly = true;
            this.rtb_rcd.Size = new System.Drawing.Size(289, 122);
            this.rtb_rcd.TabIndex = 0;
            this.rtb_rcd.Text = "";
            // 
            // rtb_cnt
            // 
            this.rtb_cnt.Location = new System.Drawing.Point(105, 198);
            this.rtb_cnt.MaxLength = 100;
            this.rtb_cnt.Name = "rtb_cnt";
            this.rtb_cnt.ReadOnly = true;
            this.rtb_cnt.Size = new System.Drawing.Size(289, 132);
            this.rtb_cnt.TabIndex = 0;
            this.rtb_cnt.TabStop = false;
            this.rtb_cnt.Text = "";
            // 
            // text_title
            // 
            this.text_title.Location = new System.Drawing.Point(105, 154);
            this.text_title.Name = "text_title";
            this.text_title.ReadOnly = true;
            this.text_title.Size = new System.Drawing.Size(257, 23);
            this.text_title.TabIndex = 9;
            this.text_title.TabStop = false;
            // 
            // text_atm
            // 
            this.text_atm.Location = new System.Drawing.Point(105, 107);
            this.text_atm.Name = "text_atm";
            this.text_atm.ReadOnly = true;
            this.text_atm.Size = new System.Drawing.Size(148, 23);
            this.text_atm.TabIndex = 10;
            this.text_atm.TabStop = false;
            // 
            // text_stm
            // 
            this.text_stm.Location = new System.Drawing.Point(105, 64);
            this.text_stm.Name = "text_stm";
            this.text_stm.ReadOnly = true;
            this.text_stm.Size = new System.Drawing.Size(148, 23);
            this.text_stm.TabIndex = 11;
            this.text_stm.TabStop = false;
            // 
            // text_id
            // 
            this.text_id.Location = new System.Drawing.Point(105, 25);
            this.text_id.Name = "text_id";
            this.text_id.ReadOnly = true;
            this.text_id.Size = new System.Drawing.Size(148, 23);
            this.text_id.TabIndex = 12;
            this.text_id.TabStop = false;
            // 
            // text_solve
            // 
            this.text_solve.Location = new System.Drawing.Point(105, 496);
            this.text_solve.Name = "text_solve";
            this.text_solve.ReadOnly = true;
            this.text_solve.Size = new System.Drawing.Size(93, 23);
            this.text_solve.TabIndex = 13;
            this.text_solve.TabStop = false;
            // 
            // btn_ok
            // 
            this.btn_ok.Font = new System.Drawing.Font("宋体", 14F);
            this.btn_ok.Location = new System.Drawing.Point(71, 554);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(127, 36);
            this.btn_ok.TabIndex = 1;
            this.btn_ok.Text = "确定";
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // btn_no
            // 
            this.btn_no.Font = new System.Drawing.Font("宋体", 14F);
            this.btn_no.Location = new System.Drawing.Point(241, 554);
            this.btn_no.Name = "btn_no";
            this.btn_no.Size = new System.Drawing.Size(119, 36);
            this.btn_no.TabIndex = 2;
            this.btn_no.Text = "返回";
            this.btn_no.UseVisualStyleBackColor = true;
            this.btn_no.Visible = false;
            this.btn_no.Click += new System.EventHandler(this.btn_no_Click);
            // 
            // admin_FeedBack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(430, 602);
            this.Controls.Add(this.btn_no);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.text_solve);
            this.Controls.Add(this.text_id);
            this.Controls.Add(this.text_stm);
            this.Controls.Add(this.text_atm);
            this.Controls.Add(this.text_title);
            this.Controls.Add(this.rtb_cnt);
            this.Controls.Add(this.rtb_rcd);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("宋体", 10.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "admin_FeedBack";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "反馈详细信息";
            this.Load += new System.EventHandler(this.admin_FeedBack_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox rtb_rcd;
        private System.Windows.Forms.RichTextBox rtb_cnt;
        private System.Windows.Forms.TextBox text_title;
        private System.Windows.Forms.TextBox text_atm;
        private System.Windows.Forms.TextBox text_stm;
        private System.Windows.Forms.TextBox text_id;
        private System.Windows.Forms.TextBox text_solve;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.Button btn_no;
    }
}