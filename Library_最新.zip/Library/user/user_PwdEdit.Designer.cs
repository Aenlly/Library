﻿namespace Library.user
{
    partial class user_PwdEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.text_pwd = new System.Windows.Forms.TextBox();
            this.text_pwds = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_pwd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "新密码：";
            // 
            // text_pwd
            // 
            this.text_pwd.Location = new System.Drawing.Point(93, 22);
            this.text_pwd.MaxLength = 16;
            this.text_pwd.Name = "text_pwd";
            this.text_pwd.Size = new System.Drawing.Size(149, 23);
            this.text_pwd.TabIndex = 0;
            this.text_pwd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_pwd_KeyPress);
            // 
            // text_pwds
            // 
            this.text_pwds.Location = new System.Drawing.Point(93, 57);
            this.text_pwds.MaxLength = 16;
            this.text_pwds.Name = "text_pwds";
            this.text_pwds.PasswordChar = '*';
            this.text_pwds.Size = new System.Drawing.Size(149, 23);
            this.text_pwds.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 14);
            this.label2.TabIndex = 2;
            this.label2.Text = "确认密码：";
            // 
            // btn_pwd
            // 
            this.btn_pwd.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_pwd.Location = new System.Drawing.Point(59, 98);
            this.btn_pwd.Name = "btn_pwd";
            this.btn_pwd.Size = new System.Drawing.Size(141, 34);
            this.btn_pwd.TabIndex = 2;
            this.btn_pwd.Text = "确定修改";
            this.btn_pwd.UseVisualStyleBackColor = true;
            this.btn_pwd.Click += new System.EventHandler(this.btn_pwd_Click);
            // 
            // user_PwdEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(272, 153);
            this.Controls.Add(this.btn_pwd);
            this.Controls.Add(this.text_pwds);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.text_pwd);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "user_PwdEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "修改密码";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text_pwd;
        private System.Windows.Forms.TextBox text_pwds;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_pwd;
    }
}